﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using ReverseProxyDistribution.Data;
using ReverseProxyDistribution.Hubs;
using ReverseProxyDistribution.Models;

namespace ReverseProxyDistribution.Services
{
    public class ConfigurationService
    {
        private readonly AppDbContext _context;
        private readonly IHubContext<ConfigurationHub> _hubContext;
        private readonly ILogger<ConfigurationService> _logger;

        public ConfigurationService(
            AppDbContext context,
            IHubContext<ConfigurationHub> hubContext,
            ILogger<ConfigurationService> logger)
        {
            _context = context;
            _hubContext = hubContext;
            _logger = logger;
        }

        public async Task<List<ConfigurationItem>> GetAllConfigurationsAsync()
        {
            return await _context.Configurations.ToListAsync();
        }

        public async Task<ConfigurationItem?> GetConfigurationAsync(int id)
        {
            return await _context.Configurations.FindAsync(id);
        }

        public async Task<ConfigurationItem> AddOrUpdateConfigurationAsync(ConfigurationItem config)
        {
            var existing = await _context.Configurations
                .FirstOrDefaultAsync(c => c.Key == config.Key);

            if (existing != null)
            {
                existing.Value = config.Value;
                existing.Type = config.Type;
                existing.Domain = config.Domain;
                existing.LastModified = DateTime.UtcNow;
                existing.Version++;
                _context.Configurations.Update(existing);
            }
            else
            {
                config.LastModified = DateTime.UtcNow;
                config.Version = 1;
                _context.Configurations.Add(config);
            }

            await _context.SaveChangesAsync();

            // Отправляем обновление всем инстансам
            await _hubContext.Clients.Group("AllInstances")
                .SendAsync("ConfigurationUpdated", existing ?? config);

            _logger.LogInformation($"Configuration updated: {config.Key}");

            return existing ?? config;
        }

        public async Task<bool> DeleteConfigurationAsync(int id)
        {
            var config = await _context.Configurations.FindAsync(id);
            if (config == null) return false;

            _context.Configurations.Remove(config);
            await _context.SaveChangesAsync();

            await _hubContext.Clients.Group("AllInstances")
                .SendAsync("ConfigurationDeleted", id);

            return true;
        }

        public async Task BlockIpAsync(string ipAddress, string reason, DateTime? expiresAt = null)
        {
            var blocked = new BlockedIp
            {
                IpAddress = ipAddress,
                Reason = reason,
                BlockedAt = DateTime.UtcNow,
                ExpiresAt = expiresAt
            };

            _context.BlockedIps.Add(blocked);
            await _context.SaveChangesAsync();

            // Немедленно отправляем блокировку на все инстансы
            await _hubContext.Clients.Group("AllInstances")
                .SendAsync("IpBlocked", blocked);

            _logger.LogWarning($"IP blocked: {ipAddress} - {reason}");
        }

        public async Task<List<BlockedIp>> GetBlockedIpsAsync()
        {
            return await _context.BlockedIps
                .Where(b => b.ExpiresAt == null || b.ExpiresAt > DateTime.UtcNow)
                .ToListAsync();
        }

        public async Task UpdateInstanceMetricsAsync(InstanceMetrics metrics)
        {
            var existing = await _context.Instances
                .FirstOrDefaultAsync(i => i.InstanceId == metrics.InstanceId);

            if (existing != null)
            {
                existing.LastSeen = DateTime.UtcNow;
                existing.ConfigVersion = metrics.ConfigVersion;
                existing.Status = metrics.Status;
                existing.RequestCount = metrics.RequestCount;
                existing.AvgLatency = metrics.AvgLatency;
                _context.Instances.Update(existing);
            }
            else
            {
                metrics.LastSeen = DateTime.UtcNow;
                _context.Instances.Add(metrics);
            }

            await _context.SaveChangesAsync();
        }

        public async Task<List<InstanceMetrics>> GetAllInstancesAsync()
        {
            return await _context.Instances.ToListAsync();
        }
    }
}