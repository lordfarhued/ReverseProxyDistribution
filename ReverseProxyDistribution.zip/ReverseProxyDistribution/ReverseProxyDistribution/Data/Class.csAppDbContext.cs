﻿using Microsoft.EntityFrameworkCore;
using ReverseProxyDistribution.Models;

namespace ReverseProxyDistribution.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<ConfigurationItem> Configurations { get; set; }
        public DbSet<InstanceMetrics> Instances { get; set; }
        public DbSet<BlockedIp> BlockedIps { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ConfigurationItem>()
                .HasIndex(c => c.Key);

            modelBuilder.Entity<InstanceMetrics>()
                .HasIndex(i => i.InstanceId);

            modelBuilder.Entity<BlockedIp>()
                .HasIndex(b => b.IpAddress);
        }
    }
}