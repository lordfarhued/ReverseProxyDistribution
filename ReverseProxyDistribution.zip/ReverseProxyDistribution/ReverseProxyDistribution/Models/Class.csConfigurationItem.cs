﻿namespace ReverseProxyDistribution.Models
{
    public class ConfigurationItem
    {
        public int Id { get; set; }
        public string Key { get; set; } = string.Empty;
        public string Value { get; set; } = string.Empty;
        public string Type { get; set; } = string.Empty; // ssl, option, route, content
        public DateTime LastModified { get; set; }
        public int Version { get; set; }
        public string? Domain { get; set; }
    }

    public class InstanceMetrics
    {
        public int Id { get; set; }
        public string InstanceId { get; set; } = string.Empty;
        public string IpAddress { get; set; } = string.Empty;
        public DateTime LastSeen { get; set; }
        public int ConfigVersion { get; set; }
        public string Status { get; set; } = "online";
        public long RequestCount { get; set; }
        public double AvgLatency { get; set; }
    }

    public class BlockedIp
    {
        public int Id { get; set; }
        public string IpAddress { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;
        public DateTime BlockedAt { get; set; }
        public DateTime? ExpiresAt { get; set; }
    }
}