﻿using Microsoft.AspNetCore.SignalR;
using ReverseProxyDistribution.Models;

namespace ReverseProxyDistribution.Hubs
{
    public class ConfigurationHub : Hub
    {
        private readonly ILogger<ConfigurationHub> _logger;

        public ConfigurationHub(ILogger<ConfigurationHub> logger)
        {
            _logger = logger;
        }

        public override async Task OnConnectedAsync()
        {
            _logger.LogInformation($"Instance connected: {Context.ConnectionId}");
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            _logger.LogInformation($"Instance disconnected: {Context.ConnectionId}");
            await base.OnDisconnectedAsync(exception);
        }

        public async Task RegisterInstance(string instanceId, string ipAddress)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, "AllInstances");
            _logger.LogInformation($"Instance registered: {instanceId} from {ipAddress}");
        }

        public async Task ReportMetrics(InstanceMetrics metrics)
        {
            _logger.LogInformation($"Metrics received from {metrics.InstanceId}");
            // Метрики будут обработаны в сервисе
        }
    }
}