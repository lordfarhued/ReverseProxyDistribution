﻿using Microsoft.AspNetCore.Mvc;
using ReverseProxyDistribution.Models;
using ReverseProxyDistribution.Services;

namespace ReverseProxyDistribution.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ConfigurationController : ControllerBase
    {
        private readonly ConfigurationService _configService;

        public ConfigurationController(ConfigurationService configService)
        {
            _configService = configService;
        }

        [HttpGet]
        public async Task<ActionResult<List<ConfigurationItem>>> GetAll()
        {
            var configs = await _configService.GetAllConfigurationsAsync();
            return Ok(configs);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ConfigurationItem>> Get(int id)
        {
            var config = await _configService.GetConfigurationAsync(id);
            if (config == null) return NotFound();
            return Ok(config);
        }

        [HttpPost]
        public async Task<ActionResult<ConfigurationItem>> Create(ConfigurationItem config)
        {
            var result = await _configService.AddOrUpdateConfigurationAsync(config);
            return CreatedAtAction(nameof(Get), new { id = result.Id }, result);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<ConfigurationItem>> Update(int id, ConfigurationItem config)
        {
            config.Id = id;
            var result = await _configService.AddOrUpdateConfigurationAsync(config);
            return Ok(result);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var success = await _configService.DeleteConfigurationAsync(id);
            if (!success) return NotFound();
            return NoContent();
        }

        [HttpPost("block-ip")]
        public async Task<ActionResult> BlockIp([FromBody] BlockIpRequest request)
        {
            await _configService.BlockIpAsync(request.IpAddress, request.Reason, request.ExpiresAt);
            return Ok();
        }

        [HttpGet("blocked-ips")]
        public async Task<ActionResult<List<BlockedIp>>> GetBlockedIps()
        {
            var ips = await _configService.GetBlockedIpsAsync();
            return Ok(ips);
        }

        [HttpGet("instances")]
        public async Task<ActionResult<List<InstanceMetrics>>> GetInstances()
        {
            var instances = await _configService.GetAllInstancesAsync();
            return Ok(instances);
        }
    }

    public class BlockIpRequest
    {
        public string IpAddress { get; set; } = string.Empty;
        public string Reason { get; set; } = string.Empty;
        public DateTime? ExpiresAt { get; set; }
    }
}